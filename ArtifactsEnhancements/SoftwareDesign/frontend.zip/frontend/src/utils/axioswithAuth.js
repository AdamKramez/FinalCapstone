// utils/axiosWithAuth.js
import axios from 'axios';

/**
 * axiosWithAuth Utility Function
 * 
 * Creates and returns an axios instance with authentication configuration
 * Automatically includes the JWT token from localStorage in all requests
 * Sets up the base URL for API endpoints
 * 
 * @returns {Object} - Configured axios instance with authentication headers
 * 
 * @example
 * // Usage in components:
 * const api = axiosWithAuth();
 * api.get('/articles')  // Automatically includes auth token
 * 
 * @description
 * This utility function creates a pre-configured axios instance that:
 * 1. Sets the base URL to the backend API endpoint
 * 2. Automatically includes the JWT token in the Authorization header
 * 3. Can be used throughout the application for authenticated API calls
 */
const axiosWithAuth = () => {
  // Retrieve the JWT token from localStorage
  const token = localStorage.getItem('token');

  // Create and return an axios instance with authentication configuration
  return axios.create({
    // Base URL for all API requests
    baseURL: 'http://localhost:5000/api',
    // Headers configuration including the authorization token
    headers: {
      Authorization: `Bearer ${token}`
    }
  });
};

export default axiosWithAuth;
