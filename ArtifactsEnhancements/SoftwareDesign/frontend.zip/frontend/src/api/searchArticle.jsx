// logic for api call to search database for an article
export const searchArticle = async (url) => {
    if (!url) throw new Error('URL is required');
  
    const response = await fetch('/api/userSearch', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url }),
    });
  
    const data = await response.json();
  
    if (!response.ok) {
      throw new Error(data.error || 'Search failed');
    }
  
    return data;
  };
  