/*
this is our main app component that sets up the routing and layout
it handles which pages to show and manages the navigation structure
*/

import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import './App.css';

// importing all our pages and components
import Home from './pages/Home';
import About from './pages/About'; 
import NavBar from './components/NavBar';
import Footer from './components/Footer';
import LoginAndRegister from './pages/LoginAndRegister';
import UserDashboard from './pages/UserDashboard';
import PrivateRoute from './components/PrivateRoute';
import GetInvolved from './pages/GetInvolved';

// this component handles the main content layout
function AppContent() {
  const location = useLocation();

  // we don't want the navbar and footer on the login page
  const isAuthPage = location.pathname === "/login";

  return (
    <div className="flex flex-col min-h-screen">
      {!isAuthPage && <NavBar />}

      <main className="flex-1">
        <Routes>
          {/* all our main routes go here */}
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<LoginAndRegister />} />
          <Route path="/about" element={<About />} />
          <Route path="/getinvolved" element={<GetInvolved />} />
          {/* dashboard is protected and requires authentication */}
          <Route path="/dashboard" element={<PrivateRoute>
                                              <UserDashboard />
                                            </PrivateRoute>
                                            }
                                        />
        </Routes>
      </main>

      {!isAuthPage && <Footer />}
    </div>
  );
}

// main app component that wraps everything in a router
function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;
