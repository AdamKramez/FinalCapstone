// src/components/SavedArticlesSlidebar.jsx
import React from 'react';

/**
 * SavedArticlesSlidebar Component
 * 
 * Displays a scrollable sidebar of saved articles
 * Shows article source, bias rating, and a link to the original article
 * 
 * @param {Object} props - Component props
 * @param {Array} props.articles - Array of saved article objects
 * @returns {React.ReactNode} - Rendered sidebar with article list
 */
const SavedArticlesSlidebar = ({ articles = [] }) => {
  return (
    <div className="w-full h-96 overflow-y-auto bg-white shadow-md rounded-lg p-4">
      <h2 className="text-xl font-semibold text-gray-800 mb-4">Saved Articles</h2>

      {articles.length === 0 ? (
        <p className="text-gray-500">You haven't saved any articles yet.</p>
      ) : (
        <ul className="space-y-3">
          {articles.map((article, idx) => (
            <li key={idx} className="border-b pb-2">
              <p className="font-medium text-gray-700">{article.news_source || 'Untitled Source'}</p>
              <p className="text-sm text-gray-500">Bias: {article.rating}</p>
              <a
                href={article.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-blue-600 hover:underline"
              >
                View article
              </a>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SavedArticlesSlidebar;
