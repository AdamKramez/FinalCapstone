import React from 'react';

/**
 * Mapping of bias rating numbers to their corresponding labels
 * Used to display human-readable bias ratings
 */
const biasLabels = {
  1: 'Left',
  2: 'Left-Center',
  3: 'Center',
  4: 'Right-Center',
  5: 'Right'
};

/**
 * Converts a bias rating number to a rotation angle for the visual indicator
 * 
 * @param {number} ratingNum - Bias rating number (1-5)
 * @returns {number} - Rotation angle in degrees
 */
const getRotationAngle = (ratingNum) => {
  switch (ratingNum) {
    case 1:
      return -40;
    case 2:
      return -20;
    case 3:
      return 0;
    case 4:
      return 20;
    case 5:
      return 40;
    default:
      return 0;
  }
};

/**
 * UserSummary Component
 * 
 * Displays a summary of the user's saved articles including:
 * - Total number of articles saved
 * - Average bias rating
 * - Visual representation of bias using a protractor and arrow
 * 
 * @param {Object} props - Component props
 * @param {Array} props.savedArticles - Array of saved article objects
 * @returns {React.ReactNode} - Summary card with statistics and visual bias indicator
 */
const UserSummary = ({ savedArticles = [] }) => {
  const articleCount = savedArticles.length;

  // Filter out any invalid ratings and calculate average
  const validRatings = savedArticles
    .map(article => article.rating_num)
    .filter(num => typeof num === 'number');

  const averageRatingNum =
    validRatings.length > 0
      ? validRatings.reduce((sum, num) => sum + num, 0) / validRatings.length
      : null;

  const roundedRatingNum = averageRatingNum !== null ? Math.round(averageRatingNum) : null;
  const averageBias = roundedRatingNum ? biasLabels[roundedRatingNum] : 'N/A';
  const rotationAngle = getRotationAngle(roundedRatingNum);

  return (
    <div className="bg-white p-6 rounded shadow-md">
      <h2 className="text-lg font-bold mb-4">Your Summary</h2>
      <p>Articles saved: {articleCount}</p>
      <p>Average bias: {averageBias}</p>

      <div className="relative mt-6 flex justify-center items-center">
        {/* protractor image background*/}
        <img
          src="/images/protractor.png"
          alt="Bias Meter"
          className="w-56 md:w-72 lg:w-80" // 🔧 change these to control size
        />

        {/* red arrow overlay */}
        {roundedRatingNum && (
          <img
            src="/images/redarrow.png"
            alt="Bias arrow"
            className="absolute transform"
            style={{
              height: '180px',                    //  adjust arrow length 
              top: '-13px',                        //  move arrow up/down
              left: '50.2%',                        // center horizontally
              transform: `translateX(-50%) rotate(${rotationAngle}deg)`, // rotate & center
              transformOrigin: 'bottom center',   // pivot from base
            }}
          />
        )}
      </div>
    </div>
  );
};

export default UserSummary;
