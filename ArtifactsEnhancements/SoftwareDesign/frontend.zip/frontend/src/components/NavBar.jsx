/*
this is our main navigation bar component
it handles user authentication state and provides navigation links
also includes a mobile-friendly menu for smaller screens
*/

import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const Navbar = () => {
  // state for mobile menu and user authentication
  const [state, setState] = useState(false); // controls mobile menu visibility
  const [user, setUser] = useState(null);    // tracks logged-in user
  const navigate = useNavigate();

  // handle mobile menu and user state
  useEffect(() => {
    // close mobile menu when clicking outside
    document.onclick = (e) => {
      const target = e.target;
      if (!target.closest(".menu-btn")) setState(false);
    };

    // load user from local storage on component mount
    const storedUser = localStorage.getItem('user');
    setUser(storedUser ? JSON.parse(storedUser) : null);

    // clean up event listener
    return () => {
      document.onclick = null;
    };
  }, []);

  // handle user logout
  const handleLogout = () => {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    setUser(null);
    navigate('/');
    window.location.reload();  // refresh page to clear state
  };

  // handle logo click - redirects to dashboard if logged in
  const handleLogoClick = () => {
    if (user) {
      navigate('/dashboard');
    } else {
      navigate('/');
    }
  };

  // navigation links for the navbar
  const navigation = [
    { title: "About", path: "/about" },
  ];

  return (
    <nav className={`bg-white pb-1 md:text-sm ${state ? "shadow-lg rounded-xl border mx-2 mt-2 md:shadow-none md:border-none md:mx-2 md:mt-0" : ""}`}>
      <div className="gap-x-14 items-center max-w-screen-xl mx-auto px-4 md:flex md:px-8">
        <div className="flex items-center justify-between py-5 md:block">
          {/* logo/brand name */}
          <button onClick={handleLogoClick}>
            <h1 className="text-xl font-bold text-gray-800">BiasTracker</h1>
          </button>

          {/* mobile menu button */}
          <div className="md:hidden">
            <button
              className="menu-btn text-gray-500 hover:text-gray-800"
              onClick={() => setState(!state)}
            >
              {state ? "X" : "☰"}
            </button>
          </div>
        </div>

        {/* main navigation links and auth buttons */}
        <div className={`flex-1 items-center mt-8 md:mt-0 md:flex ${state ? 'block' : 'hidden'} `}>
          <ul className="justify-center items-center space-y-6 md:flex md:space-x-6 md:space-y-0">
            {navigation.map((item, idx) => (
              <li key={idx} className="text-gray-700 hover:text-gray-900">
                <Link to={item.path} className="block">{item.title}</Link>
              </li>
            ))}
          </ul>

          {/* authentication buttons */}
          <div className="flex-1 gap-x-6 items-center justify-end mt-6 space-y-6 md:flex md:space-y-0 md:mt-0">
            {user ? (
              // show welcome message and logout button for logged in users
              <>
                <span className="text-gray-700">Welcome, {user.username}</span>
                <button
                  onClick={handleLogout}
                  className="py-2 px-4 text-white bg-red-600 hover:bg-red-500 rounded-full"
                >
                  Sign Out
                </button>
              </>
            ) : (
              // show login and signup buttons for guests
              <>
                <Link to="/login?mode=login" className="text-gray-700 hover:text-gray-900">Login</Link>
                <Link to="/login?mode=register" className="py-2 px-4 text-white font-medium bg-gray-800 hover:bg-gray-700 rounded-full">Sign Up</Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
