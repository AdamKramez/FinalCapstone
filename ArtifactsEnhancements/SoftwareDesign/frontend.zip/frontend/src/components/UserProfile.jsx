/*
this is the user profile component
it shows the user's information and lets them search for articles
*/

import React, { useState } from 'react';
import SearchBar from './SearchBar';
import SearchResult from './SearchResult';
import UserSummary from './UserSummary'; // <- new component

const UserProfile = ({ user }) => {
  // state for search results
  const [result, setResult] = useState(null);

  // handle saving a search result
  const handleSaveSearch = () => {
    if (!result) return;
    console.log('Save this search result to backend:', result);
    // In future: call backend to save it
  };

  return (
    <div className="flex flex-col md:flex-row p-6 gap-8">
      
      {/* LEFT - User summary */}
      <div className="md:w-1/2 bg-white shadow-md rounded-lg p-6">
        <UserSummary user={user} />
      </div>


    </div>
  );
};

export default UserProfile;
