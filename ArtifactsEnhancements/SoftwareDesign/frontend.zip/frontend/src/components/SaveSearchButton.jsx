// src/components/SaveSearchButton.jsx
import React, { useState } from 'react';
import axiosWithAuth from '../utils/axiosWithAuth';

/**
 * SaveSearchButton Component
 * 
 * A button component that handles saving articles to a user's collection
 * Manages loading, success, and error states during the save operation
 * 
 * @param {Object} props - Component props
 * @param {string} props.userId - ID of the current user
 * @param {Object} props.article - Article object to be saved
 * @returns {React.ReactNode} - Button with dynamic states and error handling
 */
const SaveSearchButton = ({ userId, article }) => {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  /**
   * Handles the article save operation
   * Makes an API call to save the article and manages UI states
   */
  const handleSave = async () => {
    setLoading(true);
    setError('');
    setSuccess(false);

    try {
      const response = await axiosWithAuth().post('/save-article', {
        userId,
        article,
      });

      if (response.status === 200) {
        setSuccess(true);
      }
    } catch (err) {
      console.error('Error saving article:', err);
      setError('Failed to save article');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="mt-4 flex items-center justify-center">
      <button
        onClick={handleSave}
        disabled={loading || success}
        className={`px-4 py-2 rounded transition font-medium text-white 
          ${success ? 'bg-green-600' : 'bg-indigo-600 hover:bg-indigo-500'} 
          ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        {loading ? 'Saving...' : success ? 'Saved!' : 'Save Search'}
      </button>
      {error && <p className="text-sm text-red-600 ml-4">{error}</p>}
    </div>
  );
};

export default SaveSearchButton;
