/*
this is our footer component that appears at the bottom of every page
it contains copyright info, navigation links, and social media icons
*/

import React from 'react';

const Footer = () => {
  return (
    <footer className="text-gray-500 bg-white px-4 py-6 max-w-screen-xl mx-auto md:px-8">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0 md:space-x-20">
        {/* copyright information */}
        <div className="text-center md:text-left text-sm">
          &copy; 2025 Tilted. All rights reserved.
        </div>

        {/* footer navigation links */}
        <ul className="flex justify-center space-x-6 text-sm">
          <li className="hover:text-gray-800">
            <a href="/about">About</a>
          </li>
          <li className="hover:text-gray-800">
            <a href="/getinvolved">Get involved</a>
          </li>
        </ul>

        {/* social media links */}
        <div className="flex justify-center md:justify-end space-x-4">
          {/* twitter icon */}
          <a href="#" className="w-10 h-10 border rounded-full flex items-center justify-center text-blue-400 hover:bg-gray-100">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M23 3a10.9 10.9 0 01-3.14 1.53A4.48 4.48 0 0022.43.36a9.14 9.14 0 01-2.89 1.1A4.52 4.52 0 0016.62 0c-2.5 0-4.52 2.04-4.52 4.56 0 .36.04.71.12 1.05C8.09 5.5 5.09 3.6 3.04.82a4.5 4.5 0 00-.61 2.3c0 1.58.8 2.98 2.02 3.8a4.5 4.5 0 01-2.05-.56v.06c0 2.2 1.56 4.04 3.63 4.46a4.5 4.5 0 01-2.04.08c.57 1.8 2.24 3.1 4.21 3.13A9.06 9.06 0 012 19.54 12.85 12.85 0 008.29 21c7.54 0 11.67-6.32 11.67-11.8 0-.18-.01-.35-.02-.53A8.5 8.5 0 0023 3z" />
            </svg>
          </a>

          {/* facebook icon */}
          <a href="#" className="w-10 h-10 border rounded-full flex items-center justify-center text-blue-700 hover:bg-gray-100">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M22.675 0H1.325C.593 0 0 .593 0 1.325v21.351C0 23.407.593 24 1.325 24h11.495v-9.294H9.692v-3.622h3.128V8.413c0-3.1 1.893-4.788 4.659-4.788 1.325 0 2.463.099 2.794.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.311h3.587l-.467 3.622h-3.12V24h6.116c.73 0 1.324-.593 1.324-1.324V1.325C24 .593 23.407 0 22.675 0z" />
            </svg>
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
