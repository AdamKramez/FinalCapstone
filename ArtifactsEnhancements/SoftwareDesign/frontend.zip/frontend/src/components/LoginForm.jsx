/*
this is our login form component
it handles user authentication and redirects to dashboard on success
*/

import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import axios from 'axios';

const LoginForm = ({ onSwitchToRegister }) => {
  const navigate = useNavigate();

  // form state
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // handle login submission
  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      // send login request to backend
      const response = await axios.post('http://localhost:5000/api/login', {
        username,
        password,
      });

      // save user data and token to local storage
      localStorage.setItem('user', JSON.stringify(response.data.user));
      localStorage.setItem('token', response.data.token);

      // redirect to dashboard
      navigate('/dashboard');
    } catch (err) {
      console.error('Login error:', err);
      setError('Invalid username or password');
    }
  };

  return (
    <div className="w-full">
      {/* header section with logo and welcome message */}
      <div className="text-center mb-6">
        <img className="mx-auto w-24" src="/images/protractor.png" alt="Logo" />
        <h4 className="mt-4 text-xl font-semibold">Welcome back</h4>
        <p className="text-gray-500">
          Log in to your account or{' '}
          <Link to="/" className="text-blue-600 underline">go back to home</Link>
        </p>
      </div>

      {/* login form */}
      <form className="space-y-4" onSubmit={handleLogin}>
        {/* username input */}
        <div>
          <label className="block text-sm font-medium text-gray-700">Username</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="you@example.com"
          />
        </div>

        {/* password input */}
        <div>
          <label className="block text-sm font-medium text-gray-700">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="••••••••"
          />
        </div>

        {/* error message display */}
        {error && <div className="text-red-600 text-sm">{error}</div>}

        {/* submit button */}
        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-500 transition"
        >
          Log in
        </button>
      </form>

      {/* registration link */}
      <div className="mt-6 text-center text-sm">
        Don't have an account?{' '}
        <button onClick={onSwitchToRegister} className="text-indigo-600 hover:underline">
          Register
        </button>
      </div>
    </div>
  );
};

export default LoginForm;
