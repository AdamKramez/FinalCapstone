import React from 'react';

const HeroSection = () => {
  return (
    <section className="flex flex-col items-center justify-center text-center py-15 px-4 bg-gray-100"
    style={{ paddingTop: '2rem', paddingBottom: '2rem' }}>
      
      {/* Big title */}
      <h1 className="text-6xl md:text-8xl font-extrabold italic text-gray-900">
        Tilted
      </h1>

      {/* Call to action */}
      <p className="mt-6 text-xl md:text-2xl text-gray-700 max-w-xl">
        Every article’s got an angle. Tilted lets you find out which way.
      </p>

    </section>
  );
};

export default HeroSection;
