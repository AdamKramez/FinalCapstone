/*
this is our registration form component
it handles new user account creation and validation
*/

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const RegisterForm = ({ onSwitchToLogin }) => {
  // form state
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');

  // handle registration submission
  const handleRegister = async (e) => {
    e.preventDefault();
    
    // check if passwords match
    if (password !== confirmPassword) {
      setError("Passwords do not match");
      return;
    }

    try {
      // send registration request to backend
      const response = await axios.post('http://localhost:5000/api/register', {
        email,
        username,
        password,
      });

      console.log('Registration success:', response.data);
      onSwitchToLogin();  // switch to login form on success
    } catch (err) {
      setError('Registration failed. Try again.');
      console.error(err);
    }
  };

  return (
    <div className="w-full">
      {/* header section with logo and welcome message */}
      <div className="text-center mb-6">
        <img
          className="mx-auto w-24"
          src="/images/protractor.png"
          alt="Logo"
        />
        <h4 className="mt-4 text-xl font-semibold">Create an Account</h4>
        <p className="text-gray-500">
          Sign up to get started or{' '}
          <Link to="/" className="text-blue-600 underline">go back to home</Link>
        </p>
      </div>

      {/* registration form */}
      <form className="space-y-4" onSubmit={handleRegister}>
        {/* email input */}
        <div>
          <label className="block text-sm font-medium text-gray-700">Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="you@example.com"
          />
        </div>

        {/* username input */}
        <div>
          <label className="block text-sm font-medium text-gray-700">Username</label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="Username"
          />
        </div>

        {/* password input */}
        <div>
          <label className="block text-sm font-medium text-gray-700">Password</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="••••••••"
          />
        </div>

        {/* confirm password input */}
        <div>
          <label className="block text-sm font-medium text-gray-700">Confirm Password</label>
          <input
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="••••••••"
          />
        </div>

        {/* error message display */}
        {error && (
          <div className="text-red-600 text-sm text-center">{error}</div>
        )}

        {/* submit button */}
        <button
          type="submit"
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-500 transition"
        >
          Register
        </button>
      </form>

      {/* login link */}
      <div className="mt-6 text-center text-sm">
        Already have an account?{' '}
        <button
          type="button"
          onClick={onSwitchToLogin}
          className="text-indigo-600 hover:underline"
        >
          Log in
        </button>
      </div>
    </div>
  );
};

export default RegisterForm;
