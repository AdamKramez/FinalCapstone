/*
this is our search bar component that lets users search for articles
it takes a url input and returns bias analysis results
*/

import React, { useState } from 'react';
import { searchArticle } from '../api/searchArticle';

const SearchBar = ({ setResult }) => {  // receives setResult function from parent
  const [url, setUrl] = useState('');

  // handle the search when button is clicked
  const handleSearch = async () => {
    try {
      const data = await searchArticle(url);
      data.url = url;  // add the url to the result data
      setResult(data);  // pass results back to parent
    } catch (err) {
      alert(err.message);
      console.error('Search error:', err);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center mt-16 px-4">
      {/* search input with icon */}
      <div className="relative w-full max-w-xl">
        <svg xmlns="http://www.w3.org/2000/svg" className="absolute left-3 top-0 bottom-0 my-auto w-6 h-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
        <input
          type="text"
          placeholder="Paste article URL here"
          className="w-full py-4 pl-12 pr-4 text-gray-700 border rounded-lg outline-none bg-gray-100 focus:bg-white focus:border-gray-400"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />
      </div>

      {/* search button */}
      <button
        onClick={handleSearch}
        className="mt-6 w-full max-w-xl py-3 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition"
      >
        Search
      </button>
    </div>
  );
};

export default SearchBar;
