/*
this is the user dashboard page
it shows the user's saved articles and lets them search for new ones
requires authentication to access
*/

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axiosWithAuth from '../utils/axiosWithAuth';

import SearchBar from '../components/SearchBar';
import SearchResult from '../components/SearchResult';
import UserSummary from '../components/UserSummary';
import SavedArticlesSlidebar from '../components/SavedArticlesSlidebar';
import SaveSearchButton from '../components/SaveSearchButton';

const UserDashboard = () => {
  // state for search results and user data
  const [result, setResult] = useState(null);
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  // get user data from local storage
  const storedUser = JSON.parse(localStorage.getItem('user'));
  const token = localStorage.getItem('token');

  // fetch latest user data from backend
  const fetchUserData = async () => {
    try {
      const response = await axiosWithAuth().get(`/user/${storedUser._id}`);
      setUser(response.data);
    } catch (err) {
      console.error('Error fetching user:', err);
      navigate('/login', { replace: true }); // redirect to login if fetch fails
    }
  };

  // check authentication and load user data
  useEffect(() => {
    if (!token || !storedUser) {
      navigate('/login', { replace: true });
    } else {
      fetchUserData();
    }
  }, []);

  // refresh user data after saving a search
  const handleSearchSaved = () => {
    fetchUserData();
  };

  if (!user) return <div className="text-center mt-10">Loading...</div>;

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* welcome header */}
      <div className="mb-10 text-center">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Welcome, {user?.username || 'User'}.
        </h1>
        <h2 className="text-xl text-gray-600">
          What political tilt would you like to measure?
        </h2>
      </div>

      {/* main dashboard layout */}
      <div className="flex">
        {/* left sidebar with saved articles */}
        <div className="w-1/2 mr-4">
          <UserSummary savedArticles={user.savedArticles} />
          <SavedArticlesSlidebar articles={user.savedArticles} />
        </div>

        {/* right side with search functionality */}
        <div className="w-1/2">
          <div className="bg-white shadow rounded-lg p-6">
            <SearchBar setResult={setResult} />
            {result && (
              <div className="mt-6">
                <SearchResult result={result} />
                {/* save search button */}
                <div className="mt-6 flex justify-center items-center gap-4">
                  <p className="italic text-gray-600 mb-0">
                    Want to add this to your searches?
                  </p>
                  <SaveSearchButton
                    userId={user._id}
                    article={result}
                    onSave={handleSearchSaved}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;
