/*
this is our home page component
it shows the search interface and handles article analysis
also manages user state and search results
*/

import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import SearchBar from '../components/SearchBar';
import HeroSection from '../components/HeroSection';
import SearchResult from '../components/SearchResult';
import UserProfile from '../components/UserProfile';

// helper function to get current user from local storage
export const getCurrentUser = () => {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
};

function Home() {
  const [result, setResult] = useState(null);
  const resultRef = useRef(null);
  const user = getCurrentUser();
  const navigate = useNavigate();

  // load previous search result when page loads
  useEffect(() => {
    const storedResult = localStorage.getItem('searchResult');
    if (storedResult) {
      setResult(JSON.parse(storedResult));
    }
  }, []);

  // scroll to results when they're updated
  useEffect(() => {
    if (result && resultRef.current) {
      resultRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }, [result]);

  // save search results to local storage
  useEffect(() => {
    if (result) {
      localStorage.setItem('searchResult', JSON.stringify(result));
    }
  }, [result]);

  // redirect to dashboard if user is logged in
  useEffect(() => {
    if (user) {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  return (
    <div className="text-center mt-0 font-sans">
      {/* show user profile or hero section based on auth state */}
      {user ? <UserProfile user={user} /> : <HeroSection />}
      
      {/* main search interface */}
      <SearchBar setResult={setResult} />
      
      {/* show results if we have them */}
      {result && <SearchResult result={result} resultRef={resultRef} />}
    </div>
  );
}

export default Home;
