// src/pages/LoginAndRegister.jsx
import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import LoginForm from '../components/LoginForm';
import RegisterForm from '../components/RegisterForm.jsx';
import Home from './Home';

/**
 * LoginAndRegister Component
 * 
 * A page component that handles both login and registration functionality
 * Features a blurred background of the home page with a centered authentication form
 * Automatically redirects to dashboard if user is already logged in
 * 
 * @returns {React.ReactNode} - Rendered login/register page with dynamic form switching
 */
const LoginAndRegister = () => {
  // Navigation and location hooks for routing and URL parameter handling
  const navigate = useNavigate();
  const location = useLocation();
  
  // Extract mode parameter from URL to determine if showing login or register form
  const queryParams = new URLSearchParams(location.search);
  const mode = queryParams.get('mode'); // e.g. ?mode=register

  // State to track whether to show login or register form
  const [isLogin, setIsLogin] = useState(true);

  /**
   * Effect to handle URL-based mode switching
   * Updates form display based on URL parameter
   */
  useEffect(() => {
    // Handle login/register mode from URL
    setIsLogin(mode !== 'register');
  }, [mode]);

  /**
   * Effect to handle authentication state
   * Redirects to dashboard if user is already logged in
   */
  useEffect(() => {
    // Check for existing authentication
    const token = localStorage.getItem('token');
    const user = localStorage.getItem('user');

    if (token && user) {
      navigate('/dashboard', { replace: true });
    }
  }, [navigate]);

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Background layer: Blurred home page for visual effect */}
      <div className="absolute inset-0 z-0 pointer-events-none filter blur-sm">
        <Home />
      </div>

      {/* Clickable overlay: Allows returning to home page */}
      <div
        className="absolute inset-0 z-10 cursor-pointer"
        onClick={() => navigate('/')}
      />

      {/* Foreground: Authentication form container */}
      <div className="relative z-20 min-h-screen flex items-center justify-center px-4">
        <div className="w-full max-w-md bg-white rounded-lg shadow-xl p-8">
          {/* Conditional rendering of login or register form */}
          {isLogin ? (
            <LoginForm onSwitchToRegister={() => setIsLogin(false)} />
          ) : (
            <RegisterForm onSwitchToLogin={() => setIsLogin(true)} />
          )}
        </div>
      </div>
    </div>
  );
};

export default LoginAndRegister;
