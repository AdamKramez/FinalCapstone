// src/pages/GetInvolved.jsx
import React from 'react';

const GetInvolved = () => {
  return (
    <div className="max-w-3xl mx-auto px-4 py-20 text-earth-text">
      <h1 className="text-4xl font-bold mb-6">Get Involved</h1>
      <p className="mb-4 text-lg">
        At <span className="font-semibold text-earth-accent">Tilted</span>, we’re always looking for ways to improve and expand our coverage of political bias in media.
      </p>
      <p className="mb-4 text-lg">
        In the near future, users will be able to:
      </p>
      <ul className="list-disc pl-6 mb-4 text-lg">
        <li>Submit articles or publications that currently don’t have a bias rating.</li>
        <li>Suggest changes or corrections to existing bias ratings.</li>
      </ul>
      <p className="text-lg">
        These features are coming soon — stay tuned and help make media transparency more accessible for everyone.
      </p>
    </div>
  );
};

export default GetInvolved;
