// src/pages/About.jsx
/*
this is our about page that explains what the app does
it describes our mission and how we assess political bias
*/

import React from 'react';

const About = () => {
  return (
    <div className="max-w-3xl mx-auto px-4 py-20 text-earth-text">
      {/* main heading and description */}
      <h1 className="text-4xl font-bold mb-6">About Tilted</h1>
      <p className="mb-4 text-lg">
        Tilted is a political bias tracker that helps users identify the leanings of news articles. 
        Whether you're curious about the tilt of a single piece or interested in analyzing your reading habits, 
        Tilted makes political bias transparent.
      </p>
      <p className="text-lg mb-10">
        Our goal is to promote media literacy and help users better understand the information they consume.
        Tilted is powered by community insights and independent research.
      </p>

      {/* methodology section */}
      <h2 className="text-2xl font-semibold mb-4">How we assess political bias?</h2>
      <p className="text-lg">
        Political bias ratings for news sources are sourced from <a href="https://www.allsides.com" target="_blank" rel="noopener noreferrer" className="underline text-earth-accent">AllSides.com</a>, 
        an organization known for its transparent and balanced methodology. AllSides uses a combination of blind surveys, third-party research, and editorial review to categorize sources into bias categories ranging from Left to Right.
      </p>
    </div>
  );
};

export default About;
