/*
this file configures our tailwind css setup
it defines our custom theme colors, fonts, and other styling preferences
basically our design system in one place
*/

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",           // for root index.html
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      // custom fonts for our typography
      fontFamily: {
        headline: ['"PlayfairDisplay"', 'serif'],
        body: ['"LibreBaskerville"', 'serif'],
      },
      // our custom color palette
      colors: {
        'earth-background': '#fdfaf6',
        'earth-hero': '#f5eee6',
        'earth-text': '#2c2c2c',
        'earth-accent': '#b5853f',
        'earth-button': '#6b4f3b',
        'earth-button-hover': '#594131',
      },
    },
  },
  plugins: [],
}

