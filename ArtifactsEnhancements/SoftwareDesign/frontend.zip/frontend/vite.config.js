/*
this file configures our vite development server and build settings
it sets up react support and handles api proxying to our backend
*/

import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(() => {
  return {
    // build output directory
    build: {
      outDir: 'build',
    },
    // plugins for our development environment
    plugins: [
      react(),
    ],
    // proxy settings for api requests
    server: {
      proxy: {
        '/api': 'http://localhost:5000', // forwards api requests to our backend
      },
    },
  };
});