const express = require('express'); //express app
const router = express.Router(); //router logic
//const jwt = require('express-jwt'); // origional
//const auth = jwt({
//    secret: process.env.JWT_SECRET,
//    userProperty: 'payload'
//});

const { expressjwt: jwt } = require('express-jwt');

const auth = jwt({
    secret: process.env.JWT_SECRET,
    algorithms: ['HS256'], // Specify the algorithm(s) used for signing the JWT
    requestProperty: 'payload',
  });
  

//this is where we import the controllers we will route
const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

//defines route for trips endpoint 
router 
    .route('/trips')
    .get(tripsController.tripsList) //GET method routes trips list 
    .post(auth, tripsController.tripsAddTrip); //POST method adds a trip

    //GET method routes TripsFindByCode - requires parameter
router 
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(auth, tripsController.tripsUpdateTrip); // put method updates a trip

// POST method routes for login authenication
router
    .route('/login')
    .post(authController.login);

// POST method routes for register authentication
router
    .route('/register')
    .post(authController.register);


module.exports = router;



