/**
 * Takes a full URL (e.g. https://www.bbc.com/news) and returns just the clean domain (e.g. bbc.com)
 * @param {string} fullUrl
 * @returns {string|null} - The cleaned domain or null if the URL is invalid
 */
const cleanUrl = (fullUrl) => {
    try {
      // Use the URL constructor to parse the input string
      const parsed = new URL(fullUrl);
  
      // Strip off 'www.' if it exists
      return parsed.hostname.replace(/^www\./, '');
    } catch (err) {
      console.error(`Could not clean URL: ${fullUrl}`);
      return null;
    }
  };
  
module.exports = cleanUrl;
